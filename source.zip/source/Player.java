package source;
import static source.ConsoleLogger.*;
public class Player {
	private String name;
	private int[] credit=new int[] {0,0,0};//credit[0] est CS,credit[1] est TM,credit[2] est **
	private int[] capacite;//[0] est capacite de math, [1] est capacite de langage, [2] est capacite d'informatique.
	private int argent=3;
	private CardManagement cm=new CardManagement();
	private CardManagement ch=new CardManagement();//cards in hand
	private ProvenanceDeEtudiant pde;
	private int superCredit=0;
	private Player gauchePlayer,droitePlayer;
	public Player(String name, ProvenanceDeEtudiant pde) {
		super();
		this.name = name;
		this.pde=pde;
		this.capacite=pde.getCapacite();
		log(BLUE_BOLD_BRIGHT + this.name+" a connecte " );



	}
	public int[] getCapacite(){return capacite;}
	public CardManagement getCm(){return cm;}
	public void setGauchePlayer(Player player){gauchePlayer=player;}
	public void setDroitePlayer(Player player){droitePlayer=player;}
	public ProvenanceDeEtudiant getPde(){return pde;}
	public CardManagement getCh(){return ch;}
	public void addBonus(String a, String b){
		for(Card card : cm.getCard()){
			if(card.getName()==a){
				for(Card card2 : cm.getCard()){
					if(card2.getName()==b){
						superCredit+=2;
					}
				}
			}
		}
	}
	public void calculerBonus(){
		addBonus("BD40\t","BD50\t");
		addBonus("LP4A\t","LP4B\t");
		addBonus("AG44\t","AG51\t");
		addBonus("GL51\t","GL52\t");
		addBonus("MT42\t","AD50\t");


	}
	public boolean calculerGagner(){
		if(ScoresCT()<7)return false;//avoir 2 stages
		if(capacite[1]<4)return false;//avoir 4 resources de Language
		if((credit[0]>=36)&&(credit[1]>=36)&&(credit[2]>=18)&&((credit[0]+credit[1])>=84)){ return true; }
		if((credit[0]+credit[1]+credit[2]+superCredit)>=102){return true;}


		return false;
	}
	public int ScoresCT(){
		int sc=0;
		for(Card card : cm.getCard()){
			if(card.getCategorie()=="ST"){
				sc+=card.getCredit();
			}
		}
		return sc;
	}
	public void calculerCT(){
		if(this.ScoresCT()>gauchePlayer.ScoresCT()){
			superCredit+=6;
		}
		if(this.ScoresCT()>droitePlayer.ScoresCT()){
			superCredit+=6;
		}
	}
	public boolean jetterCard(int i){argent+=3;log("Le joueur " + this.name + " a jette la carte " + RED_BOLD+ch.getCard(i).getName());return true;}
	public boolean acheterDroiteCard(int i){
		if(ch.getCard(i).getCost()[3]>0){return false;}
		if ((droitePlayer.getCapacite()[0] <= capacite[0]) && (droitePlayer.getCapacite()[1] <= capacite[1]) && (droitePlayer.getCapacite()[2] <= capacite[2])) {
			return true;
		}
		return false;
	}
	public boolean acheterGaucheCard(int i){
		if(ch.getCard(i).getCost()[3]>0){return false;}
		if ((gauchePlayer.getCapacite()[0] <= capacite[0]) && (gauchePlayer.getCapacite()[1] <= capacite[1]) && (gauchePlayer.getCapacite()[2] <= capacite[2])) {
			return true;
		}
		return false;
	}
	public boolean useCard(int i){


		for(int j=0;j<cm.size();j++){
			if(cm.getCard(j).getName()==ch.getCard(i).getName()){
				log(YELLOW +"Le joueur " + this.name + " a deja appris la carte " + RED_BOLD+ch.getCard(i).getName());
				return false;
			}
		}
	//	if (ch.getCard(i).getCost()[3] >=argent){log(YELLOW +"Le joueur " + this.name + " n'a pas assez d'argent " + RED_BOLD+ch.getCard(i).getName());return false;}

			if ((ch.getCard(i).getCost()[0] <= capacite[0]) && (ch.getCard(i).getCost()[1] <= capacite[1]) && (ch.getCard(i).getCost()[2] <= capacite[2])&&(ch.getCard(i).getCost()[3]==0)) {
				capacite[0] -= ch.getCard(i).getCost()[0];
				capacite[1] -= ch.getCard(i).getCost()[1];
				capacite[2] -= ch.getCard(i).getCost()[2];
				capacite[0] += ch.getCard(i).getGain()[0];
				capacite[1] += ch.getCard(i).getGain()[1];
				capacite[2] += ch.getCard(i).getGain()[2];
				if (ch.getCard(i).getCredit() != 0) {
					if (ch.getCard(i).getCategorie() == "CS") {
						credit[0] += ch.getCard(i).getCredit();
					}
					if (ch.getCard(i).getCategorie() == "TM") {
						credit[1] += ch.getCard(i).getCredit();
					}
					if (ch.getCard(i).getFiliereCours()) {
						credit[2] += ch.getCard(i).getCredit();
					}

				}
				return true;

		}
			if ((ch.getCard(i).getCost()[3] <= argent)&&(ch.getCard(i).getCost()[3]>0)){argent -= ch.getCard(i).getCost()[3];return true;}






return false;
	}
	public int CardAction(){
		for(int i=0;i<this.getCh().size();i++){
			if(useCard(i)){
				log("Le joueur " + this.name + " a posé la carte " + RED_BOLD+ch.getCard(i).getName());
				this.ch.moveTo(i,cm);
				return 1;
			}
		}
		for(int i=0;i<this.getCh().size();i++){
			if(acheterGaucheCard(i)){
				int a=ch.getCard(i).getCost()[0] - capacite[0];
				if(a<0) a=0;
				int b=ch.getCard(i).getCost()[1] - capacite[1];
				if(b<0) b=0;
				int c=ch.getCard(i).getCost()[2] - capacite[2];
				if(c<0) c=0;
				log("Le joueur " + this.name + " a paye " +(a+b+c)+" a "+gauchePlayer.getName()+" pour poser la carte"+RED_BOLD+ch.getCard(i).getName());
				this.argent+=(a+b+c);
				this.ch.moveTo(i,cm);
				return 1;
			}
		}
		for(int i=0;i<this.getCh().size();i++){
			if(acheterGaucheCard(i)){
				int a=ch.getCard(i).getCost()[0] - capacite[0];
				if(a<0) a=0;
				int b=ch.getCard(i).getCost()[1] - capacite[1];
				if(b<0) b=0;
				int c=ch.getCard(i).getCost()[2] - capacite[2];
				if(c<0) c=0;
				log("Le joueur " + this.name + " a paye " +(a+b+c)+"a"+droitePlayer.getName()+"pour poser la carte"+RED_BOLD+ch.getCard(i).getName());
				this.argent+=(a+b+c);
				this.ch.moveTo(i,cm);
				return 1;
			}
		}
		jetterCard(0);
		this.ch.removeCard(ch.getCard(0));
		return 0;
	}
	public void pdeAction(){
		int age=this.cm.getAge();
		//log(RED +"age"+cm.getAge());
		if(age==0){return;}
		if(!pde.getAge(age).getStatues()) {
			if ((pde.getAge(age).getCost()[0] <= capacite[0]) && (pde.getAge(age).getCost()[1] <= capacite[1]) && (pde.getAge(age).getCost()[2] <= capacite[2])) {
				argent+=pde.getAge(age).getGain()[0];
				capacite[0] -= pde.getAge(age).getCost()[0];
				capacite[1] -= pde.getAge(age).getCost()[1];
				capacite[2] -= pde.getAge(age).getCost()[2];
				capacite[0] += pde.getAge(age).getGain()[1];
				capacite[1] += pde.getAge(age).getGain()[2];
				capacite[2] += pde.getAge(age).getGain()[3];
				superCredit+=pde.getAge(age).getGain()[4];
				pde.getAge(age).changeStatus();
				log("Le joueur " + this.name + " a utilise sa pde " +PURPLE_BOLD+pde.getName()+" de "+pde.getAge(age).getAge());
			}
		}
	}
	public void Action(){
		this.CardAction();
		this.pdeAction();
	}
	public void giveback(CardManagement cm){
		while(!this.ch.isZero()){this.ch.moveTo(0,cm);}
	}
	public String toString() {
		String s=new String("Player name:"+name+"\n"+"Credit:\t\tCS:"+credit[0]+"/30\t\tTM:"+credit[1]+"/30\t\t**:"+credit[2]+"/30\tSuperCredit:"+superCredit+"\nCapacite:\tMath:"+capacite[0]+"\t\tLangage:"+capacite[1]+"\tInfo:"+capacite[2])+"\nL'argent:"+argent+"\n"+cm.toString();
		//the version without pde


		//String s=new String("Player name:"+name+"\n"+pde+"Credit:\t\tCS:"+credit[0]+"/30\t\tTM:"+credit[1]+"/30\t\t**:"+credit[2]+"/30\tSuperCredit:"+superCredit+"\nCapacite:\tMath:"+capacite[0]+"\t\tLangage:"+capacite[1]+"\tInfo:"+capacite[2])+"\nL'argent:"+argent+"\n"+cm.toString();
		//the version with pde
		return s;
	}
	public void print(){
		log(PURPLE+toString());
	}
	public String getName(){return this.name;}
	public boolean addCard(Card c) {
		if(c.getCost()[0]<=capacite[0]&&c.getCost()[1]<=capacite[1]&&c.getCost()[2]<=capacite[2]&&c.getCost()[3]<=argent) {
			this.cm.addCard(c);
			capacite[0]=capacite[0]-c.getCost()[0]+c.getGain()[0];
			capacite[1]=capacite[1]-c.getCost()[1]+c.getGain()[1];
			capacite[2]=capacite[2]-c.getCost()[2]+c.getGain()[2];
			argent=argent-c.getCost()[3];
			if(c.getCategorie().equals("CS")) {
				credit[0]+=c.getCredit();
			}
			else if(c.getCategorie().equals("TM")) {
				credit[1]+=c.getCredit();
			}
			if(c.getFiliereCours()==true) {
				credit[2]+=c.getCredit();
			}
			checkStatus(0);
			//cm.removeCard(c);
			log(PURPLE+"OK!\n"+this.toString());
			
			return true;
		}
		return false;
		
	}
	public void checkStatus(int n) {
		if(capacite[0]>=pde.getAge(n).getCost()[0]&&capacite[1]>=pde.getAge(n).getCost()[1]&&capacite[2]>=pde.getAge(n).getCost()[2]) {
			argent=argent+pde.getAge(n).getGain()[3];
			superCredit+=pde.getAge(n).getGain()[4];
			pde.getAge(n).changeStatus();
		}
		
	}
	public void earnMoney() {
		argent+=3;
		System.out.println(this);
	}
	public void payMoney() {
		argent-=2;
	}
//	public static void main(String[] args) {
//		
//		Player player1=new Player("xhh",p1);
//		System.out.println(player1);
//		CardManager cm=new CardManager();
//		cm.initial();
//		player1.addCard(cm.getCard(1));
//		//System.out.println(player1);
//
//	}

}
