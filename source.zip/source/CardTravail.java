package source;

public class CardTravail extends Card {
	private int point;
	private String categorie;//TM et CS et ST
	private boolean filiereCours=false;
	public CardTravail(String name, int[] cost, int[] gain, int point, String categorie, boolean filiereCours) {
		super(name, cost, gain);
		this.point = point;
		this.categorie = categorie;
		this.filiereCours=filiereCours;
	}


	@Override
	public String getCategorie() {
		return categorie;
	}

	@Override
	public int getCredit() {
		return point;
	}
	@Override
	public String toString() {
		return super.toString()+"\t|"+ point +"\t|" + categorie+"\t\t|"+filiereCours+"\n" ;
	}

	@Override
	public boolean getFiliereCours() {
		return filiereCours;
	}

}
