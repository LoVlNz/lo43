package source;
import static source.ConsoleLogger.*;
import java.util.ArrayList;
import java.util.Scanner;

public class GameManagement {

	private final static ProvenanceDeEtudiantManagement pdem = new ProvenanceDeEtudiantManagement();
	private final static Player player1 = new Player("xhh", pdem.getProvenanceDeEtudiant(0));
	private final static Player player2 = new Player("zrq", pdem.getProvenanceDeEtudiant(1));
	private final static Player player3 = new Player("fjw", pdem.getProvenanceDeEtudiant(2));
	private final static Player[] players = new Player[]{player1, player2, player3};
	private static int age = 1;
	private static int tour = 1;
	private static CardManagement cm = new CardManagement();

	public final static void printPlayer() {
		for (Player player : players) {
			log(BLUE_BOLD_BRIGHT + player.getName() + " a reçu sa vision de jeu");
			player.print();

		}
	}

	public final static void setVoisine() {
		player1.setDroitePlayer(player2);
		player1.setGauchePlayer(player3);
		player2.setGauchePlayer(player1);
		player2.setDroitePlayer(player3);
		player3.setGauchePlayer(player2);
		player3.setDroitePlayer(player1);
		log(BLUE_BOLD_BRIGHT + "all player have seated!");
		log(CYAN_BOLD + "\t ____");
		log(CYAN_BOLD + "fjw" + "\t" + "|\t" + " | zrq");
		log(CYAN_BOLD + "\t|____|");
		log(CYAN_BOLD + "\t xhh");

	}

	public final static void distributionCard() {
		log(GREEN_BOLD + "Distribution des cards\n");
		for (Player player : players) {
			for (int i = 0; i < (8 - tour); i++) {

				cm.moveTo(0, player.getCh());
			}
		}
		//cm.moveTo(0,player1.getCh());
		log(BLUE_BOLD_BRIGHT + player1.getName() + ":\n" + player1.getCh());
		log(BLUE_BOLD_BRIGHT + player2.getName() + ":\n" + player2.getCh());
		log(BLUE_BOLD_BRIGHT + player3.getName() + ":\n" + player3.getCh());


	}

	public final static void tour() {
		log(GREEN_BOLD + "\nDébut du tour " + tour);
		log(GREEN_BOLD + "-------------------------\n");
		distributionCard();

		for (Player player : players) {
			player.Action();
			player.giveback(cm);
		}
		for (Player player : players) {
			player.getCm().getCard(0).setAge(age);

		}
		log(cm);
		log(YELLOW + "\nFin du tour " + tour + " de l'âge " + age);
		tour++;
	}

	public final static void calculerCT() {
		log(YELLOW + "\nclaculerCT :");
		for (Player player : players) {
			player.calculerCT();
			log(player.ScoresCT());

		}


	}

	public final static void printScores() {
		log(YELLOW + "Les scores :");
		for (Player player : players) {
			log(YELLOW + player);

		}
	}

	public final static void Jeu() {
		log(GREEN_BOLD + "début de l'âge " + age + "\n");
		log(GREEN_BOLD + "Preparation de card de l'âge " + age + "\n");
		cm.initial(age);
		while (tour <= 7) {
			tour();
		}
		log(YELLOW + "\nFin du tour " + (tour - 1) + " de l'âge " + age);
		calculerCT();
		printScores();
		log("\n--------------------");
		log("- Fin de l'Age " + age + " ! -");
		log("--------------------\n");


		age++;
		tour = 1;

	}

	public final static void SeparationdePde() {
		for (Player player : players) {
			log(BLUE_BOLD_BRIGHT + player.getName() + " a reçu sa provenance d'etudiant");
			log(PURPLE + player.getPde());

		}
	}

	public final static void calculerGagner() {
		for (Player player : players) {
			if(player.calculerGagner()){
				log(BLUE_BOLD_BRIGHT + "Le joueur " + player.getName() + " a reussi!!");
			}
			else {
				log(BLUE_BOLD_BRIGHT + "Le joueur " + player.getName() + " a echou!!");
			}
		}
	}

	public final static void calculerBonus() {
		for (Player player : players) {
			player.calculerBonus();
		}

	}

	public final static void main(String[] args) {
		log(YELLOW_BOLD_BRIGHT + "\n-------------------------------------");
		log(YELLOW_BOLD_BRIGHT + "- 7 WONDERS : nombre de joueurs : 3 -");
		log(YELLOW_BOLD_BRIGHT + "-------------------------------------\n");
		setVoisine();
		SeparationdePde();
		while (age <= 3) {
			Jeu();
		}
		calculerBonus();
		printScores();
		calculerGagner();
		log(YELLOW_BOLD_BRIGHT + "Fin du jeu !");
	}
}