package source;
import java.io.FileNotFoundException;
import java.io.PrintStream;

public class Out {

    public Out(){
        try {

            PrintStream print=new PrintStream("test2.txt");  //写好输出位置文件；
            System.setOut(print);
        } catch (FileNotFoundException e) {
            e.printStackTrace();
        }
    }
    public static void main(String [] args)
    {
        Out o= new Out();// 构造对象
        System.out.print("Reallly?");
        System.out.println("Yes");
        System.out.println("So easy");


    }

}