package source;
import static source.ConsoleLogger.*;
import java.util.ArrayList;
import java.util.Random;

public class CardManagement {
	private ArrayList<Card> card;
	public CardManagement(ArrayList<Card> card) {
		super();
		this.card = card;
	}
	
	public CardManagement() {
		card=new ArrayList<Card>();
	}

	@Override
	public String toString() {
		String s=new String("Cours\t\t|\t"+" "+" "+" "+"Cost\t\t|\tGain\t|Cre|Cate\t|**\n\t\t\t|Ma |Lan|Inf|Ar |Ma |Lan|Inf|\t|\t\t|\n");
		for(Card c:card) {
			s=s+c.toString();
		}
		s+="------------------------------------------------------------------------------------------------------------------------\n";
		return s;
	}
	public void print(){
		log(toString());
	}
	public ArrayList<Card> getCard(){return card;};
	public boolean isZero(){return card.isEmpty();}
	public int size(){return this.card.size();}
	public int getAge(){
		int max=-1;
		for(int i=0;i<card.size();i++){
			if(card.get(i).getAge()>max){
				max=card.get(i).getAge();
			}
		}
		return max;
	}
	public void moveTo(int i,CardManagement cm){
		cm.addCard(getCard(i));
		removeCard(getCard(i));

	}
	public void initial(int ages) {
		//CS
		CardCours cs1=new CardCours("LO43\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "CS", false) ;
		CardCours cs2=new CardCours("MT42\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "CS", false) ;
		CardCours cs3=new CardCours("BD40\t", new int[] {0,1,1,0}, new int[] {0,1,1}, 6, "CS", false) ;
		CardCours cs4=new CardCours("LP4A\t", new int[] {1,1,0,0}, new int[] {1,1,0}, 3, "CS", false) ;
		CardCours cs5=new CardCours("LP4B\t", new int[] {0,1,1,0}, new int[] {0,1,1}, 3, "CS", false) ;
		CardCours cs6=new CardCours("AG44\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "CS", false) ;
		
		//TM
		CardCours tm1=new CardCours("AD50\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "TM", false) ;
		CardCours tm2=new CardCours("AG51\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "TM", false) ;
		CardCours tm3=new CardCours("BD50\t", new int[] {0,1,1,0}, new int[] {0,1,1}, 6, "TM", true) ;
		CardCours tm4=new CardCours("BD51\t", new int[] {1,1,0,0}, new int[] {1,1,0}, 3, "TM", true) ;
		CardCours tm5=new CardCours("GL51\t", new int[] {0,1,1,0}, new int[] {0,1,1}, 3, "TM", true) ;
		CardCours tm6=new CardCours("GL52\t", new int[] {1,0,1,0}, new int[] {1,0,1}, 6, "TM", true) ;
		
		//Capacite
		CardCapacite c1=new CardCapacite("Calcul\t", new int[] {0,0,0,0}, new int[] {2,1,0});
		CardCapacite c2=new CardCapacite("Anglais\t", new int[] {0,0,0,0}, new int[] {0,2,1});
		CardCapacite c3=new CardCapacite("Algo\t", new int[] {0,0,0,0}, new int[] {1,0,2});
		CardCapacite c4=new CardCapacite("Finances", new int[] {0,0,0,0}, new int[] {2,0,0});
		CardCapacite c5=new CardCapacite("PS\t\t", new int[] {0,0,0,0}, new int[] {0,0,2});
		CardCapacite c6=new CardCapacite("Traduction", new int[] {0,0,0,0}, new int[] {0,2,0});

		//Stage
		CardTravail ct1=new CardTravail("ST30\t", new int[] {0,0,0,1}, new int[] {0,0,0}, 2, "ST", false);
		CardTravail ct2=new CardTravail("ST40\t", new int[] {0,0,0,2}, new int[] {0,0,0}, 4, "ST", false);
		CardTravail ct3=new CardTravail("ST50\t", new int[] {0,0,0,3}, new int[] {0,0,0}, 6, "ST", false);
		if(ages==1) {
			card=new ArrayList<Card>();
			Card[] c = new Card[]{c1, c2, c3, c4, c5, c6};
			Card[] ct= new Card[]{ct1,ct2,ct3};
			for (Card card : c) {
				card.setAge(ages);
				this.card.add(card);



			}
			for (Card card : ct) {
				card.setAge(ages);
				this.card.add(card);


			}
			for (Card card : c) {
				this.card.add(card);


			}
			for (Card card : c) {
				this.card.add(card);


			}
		}
		if(ages==2) {
			card=new ArrayList<Card>();
			Card[] cs = new Card[]{cs1, cs2, cs3, cs4, cs5, cs6};
			Card[] ct= new Card[]{ct1,ct2,ct3};
			for (Card card : cs) {
				card.setAge(ages);
				this.card.add(card);


			}
			for (Card card : ct) {
				card.setAge(ages);
				this.card.add(card);


			}
			for (Card card : cs) {
				this.card.add(card);


			}
			for (Card card : cs) {
				this.card.add(card);


			}
		}
		if(ages==3) {
			card=new ArrayList<Card>();
			Card[] tm = new Card[]{tm1, tm2, tm3, tm4, tm5, tm6};
			Card[] ct= new Card[]{ct1,ct2,ct3};
			for (Card card : tm) {
				card.setAge(ages);
				this.card.add(card);


			}
			for (Card card : ct) {
				card.setAge(ages);
				this.card.add(card);


			}
			for (Card card : tm) {
				this.card.add(card);


			}
			for (Card card : tm) {
				this.card.add(card);


			}
		}

	}
	public void addCard(Card c) {
		if(c.getCredit()==0) {
			CardCapacite cd=new CardCapacite(c.getName(), c.getCost(), c.getGain());
			this.card.add(cd);
		}
		else {
			CardCours cd=new CardCours(c.getName(), c.getCost(),c.getGain(), c.getCredit(), c.getCategorie(), c.getFiliereCours());
			this.card.add(cd);
		}
			
		
	}
	public void removeCard(Card c) {
		this.card.remove(c);
	}
	public Card getCard(int index){
		return this.card.get(index);
	}
	public void showCard() {
		String s=new String("No.\t|Cours\t|\t"+" "+" "+" "+"Cost\t\t\t|\tGain\t\t|Credit\t|Categorie\t|**\n\t\t|Math\t|Langage|Info\t|Argent\t|Math\t|Langage|Info\t|\t|\t\t|\n");
		s+="#1\t"+card.get((int)(Math.random()*5/1));
		s+="#2\t"+card.get((int)(Math.random()*5/1));
		s+="#3\t"+card.get((int)(Math.random()*5/1));
		s+="#4\t"+card.get((int)(Math.random()*5/1));
		s+="#5\t"+card.get((int)(Math.random()*5/1));
		s+="#6\t"+card.get((int)(Math.random()*5/1));
		System.out.println(s);
	}
	public static void main(String[] args) {
		CardManagement cm=new CardManagement();
		CardManagement cm3=new CardManagement();
		cm.initial(3);
		cm.moveTo(0,cm3);
		log(cm.getAge());
		//cm.removeCard(cm.getCard(0));
		System.out.println(cm3);
//		ArrayList<Integer> a=new ArrayList<Integer>();
//		a.add(1);
//		System.out.println(a);

	}

}
